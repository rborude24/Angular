import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BinLaughComponent } from './bin-laugh.component';

describe('BinLaughComponent', () => {
  let component: BinLaughComponent;
  let fixture: ComponentFixture<BinLaughComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BinLaughComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BinLaughComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
