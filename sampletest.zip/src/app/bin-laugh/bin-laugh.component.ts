import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-bin-laugh',
  templateUrl: './bin-laugh.component.html',
  styleUrls: ['./bin-laugh.component.css']
})
export class BinLaughComponent implements OnInit {

  constructor() { }

  @Input('bin') bin: string = '';
  @Input('laugh') laugh: string = '';

  @Output() myOutput: EventEmitter<string>= new EventEmitter();
  outputValue:string = 'Hello From Child';

  makeNoise() {
    alert(`${this.laugh}`);
  }

  makeLaugh(){
    this.myOutput.emit(this.outputValue);
  }

  ngOnInit(): void {
    console.log(this.bin);
    console.log(this.laugh);
  }

}
