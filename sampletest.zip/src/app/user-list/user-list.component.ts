import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { from } from 'rxjs';

import {filter, map, toArray} from 'rxjs/operators';



interface SAMPLE {
  name:string,
  id:string,
  isActive:boolean,
  email:string,
  phone:string
  }

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})


export class UserListComponent implements OnInit {
  inputText:string = '';
  // data!: MatTableDataSource<{ id: string; isActive: boolean; name: string; email: string; phone: string; } | { id: string; isActive: boolean; name: string; phone: string; email?: undefined; }>;
  data:any;
  originalData:any;
  isActive: boolean | undefined;

  constructor() { }

  userData = [{ "id": "1", "isActive": false, "name": "Orr Pruitt", "email": "Davis.Schmidt@example.com", "phone": "+1 (825) 448-3195" },
  { "id": "2", "isActive": true, "name": "Roslyn Stuart", "email": "Sarah.Rosales@example.com", "phone": "+1 (910) 467-3569" },
  { "id": "3", "isActive": false, "name": "Durham Prince", "email": "Guthrie.Moses@example.com", "phone": "+1 (866) 581-3918" },
  { "id": "4", "isActive": true, "name": "Christine Hahn", "email": "Kristin.Pate@example.com", "phone": "+1 (855) 590-2321" },
  { "id": "5", "isActive": false, "name": "Tara Gill", "email": "Calderon.Mayo@example.com", "phone": "+1 (910) 492-3751" },
  { "id": "6", "isActive": false, "name": "Gillespie Richards", "email": "Shelly.Fulton@example.com", "phone": "+1 (889) 594-3171" },
  { "id": "7", "isActive": true, "name": "Celina Hebert", "email": "Vang.Leblanc@example.com", "phone": "+1 (886) 438-2289" },
  { "id": "8", "isActive": false, "name": "Mills Nielsen", "email": "Arlene.Santos@example.com", "phone": "+1 (945) 599-3756" },
  { "id": "9", "isActive": true, "name": "Alexis Mays", "email": "Mullen.Cain@example.com", "phone": "+1 (876) 487-2599" },
  { "id": "10", "isActive": false, "name": "Aguilar Joyce", "email": "Ivy.Whitehead@example.com", "phone": "+1 (838) 470-2654" },
  { "id": "11", "isActive": true, "name": "Carver Fields", "email": "Yang.Cantrell@example.com", "phone": "+1 (864) 458-3909" },
  { "id": "12", "isActive": true, "name": "Vazquez Carlson", "email": "Avery.Vaughn@example.com", "phone": "+1 (892) 492-3779" },
  { "id": "13", "isActive": false, "name": "Liz Randolph", "phone": "+1 (882) 598-3098" }];

  ngOnInit(): void {
    from(this.userData).pipe(toArray()).subscribe(res=>
      {
        console.log(res);
        this.data = res;
        this.originalData = res;
      })
  }

  getChildData(event:any){
    console.log(event);
    this.inputText = event;


    this.data = this.originalData.filter((item:SAMPLE) => item.name.includes(this.inputText)
    || item.id.includes(this.inputText)
    || item.email?.includes(this.inputText)
    || item.phone?.includes(this.inputText));
  }


  selectedChange(event:any){debugger
    if(event == 1)
    this.isActive = true;
    else
    this.isActive = false;

    if(event =='Select Status'){
      this.data = this.originalData
    }else{
    this.data = this.originalData.filter((item:SAMPLE)=> item.isActive == this.isActive);
    }
    // var t1 = from(this.userData);

    // this.data = t1.pipe(filter(item=>item.isActive == isActive),toArray());



  }

}
