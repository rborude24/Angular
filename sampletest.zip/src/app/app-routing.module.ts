import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { BinLaughComponent } from './bin-laugh/bin-laugh.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserSearchFilterComponent } from './user-search-filter/user-search-filter.component';

const routes: Routes = [
  // {path:'',component:BinLaughComponent,pathMatch:'full'},
  {path:'userlist',component:UserListComponent},
  {path:'userfilter',component:UserSearchFilterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
