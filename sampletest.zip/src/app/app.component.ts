import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'sampletest';
  bin:string = 'This is Bin From Parent';
  laugh:string = 'This is Laugh from Parent';

  inputFromChild:any;

  ngOnInit(){
  }

  getChildData(event:any){
    console.log(event);
    alert(event);

  }

}
